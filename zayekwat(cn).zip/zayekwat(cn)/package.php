<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ZayeKwat</title>
    <!--font awesome css-->
    <link rel="stylesheet" href="./css/all.css">

    <!--bootstrap css-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <!--my css-->
    <link rel="stylesheet" href="css/main.css">
    <link href="css/simple-sidebar.css" rel="stylesheet">
    <!--google font-->
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@100&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>

<body>




    <!-- Use any element to open the sidenav -->

    <!-- Sidebar -->

    <div class="d-flex " id="wrapper">
        <div class=" border-right side" id="sidebar-wrapper">

            <div class="list-group list-group-flush p-3 m-auto">
                <a class="navbar-brand text-center" href="#" class="list-group-item list-group-item-action center">
                    <img src="image/icon1.png" alt="" width="80px" height="80px" class="img-thumbnail rounded-circle mt-2">
                    <div style="color: black;" class="text-center"><?php error_reporting(1); session_start(); echo $_SESSION['usname']; ?></div>
                </a>
                <span class="list-group-item list-group-item-action"> <?php echo date("d/ m / yy") ?></span>
                 <a href="index.php" class="list-group-item list-group-item-action">ပရိုဖိုင်</a>
                <a href="import.php" class="list-group-item list-group-item-action">သွင်းကုန်</a>
                <a href="export.php" class="list-group-item list-group-item-action">ပို့ကုန်</a>
                <a href="#" class="list-group-item list-group-item-action">ငွေကြေးမှတ်တမ်းများ</a>
                <a href="#" class="list-group-item list-group-item-action">ငွေကြေးလဲလှယ်နှုန်း</a>
                <a href="#" class="list-group-item list-group-item-action">အကူအညီ</a>
                <a href="#" class="list-group-item list-group-item-action ">အသုံးပြုပုံ</a>

            </div>
        </div>
        <!-- /#sidebar-wrapper -->



        <!-- /#page-content-wrapper -->
        <div id="page-content-wrapper">
            <nav class="navbar   navclass fixed-top">

                <a class="" href="index.php">
                    <img src="image/logo1.png" width="150px" height="80px" class="" alt="">
                </a>
                <a href="#" class="icon ml-auto" target="_blank" rel="noopener noreferrer">
                    <i class="fab fa-facebook-messenger"></i></a>
               

            </nav>

            <section class="container-fluid fixed-top mt-4 shadow p-3 mb-5 bg-white rounded nav_sec">
                <div class="row">


                    <div class="col col-sm-4 text-center border-right"><button class="btn " id="menu-toggle"> <i class=" fa fa-bars" aria-hidden="true"></i></button></div>
                     <div class="col col-sm-4 text-center border-right"> <a href="index.php"><i class=" fa fa-home" aria-hidden="true"></i></a></div>
                    <div class="col col-sm-4 text-center "><i class="fa fa-bell" aria-hidden="true"></i></div>
                </div>
            </section>



            <!-- /#wrapper -->

            <!--- page contant---->

		<form method="post">
			<div class="container main text-left">
                <div class="row">
				<?php
	error_reporting(1);
	session_start();
	include("engine/connection.php");
	date_default_timezone_set('Asia/Rangoon');
	$script_tz = date_default_timezone_get();
	if(strcmp($script_tz, ini_get('date.timezone')))
	{
		$ans=date("h:i:sa");
		$request2=date('d-m-y');
	}
	else
	{
		echo 'Script timezone and ini-set timezone match.';
	}
	$start_date_time = date('Y-m-d H:i:s');
	
	
	
	$return="SELECT * FROM package  ORDER BY `id` DESC";
	$query=mysqli_query($mysqli,$return);
	while($submit=mysqli_fetch_array($query))
	{
	$package=$submit['package_name'];
	$cost=$submit['cost'];
	$expire=$submit['expire'];
	$_SESSION['package_type']=$package;
	$_SESSION['cost']=$cost;
	$_SESSION['expire']=$expire;
	
	
?>
                    <div class="card col-sm-4 col-md-3 col-lg-4 mb mr-auto ml-auto shadow p-3 mb-5 bg-white rounded" style="width: 18rem;">
                        <div class="card-body bd">
                            <h5 class="card-title">ဒေတာကယ်ရီ</h5>
							<hr>
                            <p class="card-text">ပက်ကေ့ချ်အမျိုးအစား &emsp;&emsp;&nbsp;<br></bt><span><?php error_reporting(1); echo" : $package" ?>"</span></p>
                            <p class="card-text">သက်တမ်း &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</br><span><?php error_reporting(1); echo":$expire ရက်"; ?></span></p>
                            <p class="card-text">ကျသင့်ငွေ &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</br><span><?php error_reporting(1); echo":$cost ကျပ်"; ?></span></p>
							<p align="center"><a href='trans.php?package_type=<?php echo "$package"; ?> & cost=<?php echo "$cost"; ?> & expire=<?php echo "$expire"; ?>'><button type="button" class="btn btn-primary m-auto">ဝယ်ယူမည်။😊</button></a></p>
					

                        </div>
                    </div>
					<?php } ?>
				</div>
            </div>
		</div>
		</form>

            

            <!-----end------>


            <!--footer bar-->
            <footer>
                <div class="container-fluid foot text-center">
                    Power By MWTC

                </div>
            </footer>

            <!--bootstrap js-->
            <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
            <!--fontawesome js-->
            <script src="./js/all.js"></script>

            <!--jquery-->
            <script src="./js/jquery-3.5.0.min.js"></script>
            <script src="./js/jquery.min.js"></script>
            <!--menu js-->

            <script>
                $("#menu-toggle").click(function(e) {
                    e.preventDefault();
                    $("#wrapper").toggleClass("toggled");
                });
            </script>

</body>

</html>

<!--<script>
    $("#menu-toggle").click(function (e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>-->