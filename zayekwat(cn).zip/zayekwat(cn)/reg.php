<!DOCTYPE html>
<html lang="en">

<head>
    <!---- SEO ----->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
   

    <!------------------------------Css link here-------------------------------------->
    <!--Fontawesome Css-->
    <link rel=" stylesheet" href="css/all.css">

    <!--bootstrap Css-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <!-- w3-css -->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

    <!--- Css Style---->
    <link rel="stylesheet" href="css/main.css">
    <!-------------------------------------- End -------------------------------------------->

</head>


<body id="grad">

    <!--- login form ---->
<form method="post" action="engine/reg_source.php">
    <div class="container bg-light login-con p-5 rounded w3-animate-bottom shadow-lg p-3 mb-5 bg-white rounded">
        <form action="/home.php" class="login-form">
            <h2 class="form-login heading text-center">
                မှတ်ပုံတင်ရန်
            </h2>
            <div class="login-warp">
                <input type="text" class="form-control" name="us" placeholder="အမည် " required >
                <input type="text" class="form-control mt-2" name="sp" placeholder="ဆိုင်အမည်" required >
                <select class="form-control mt-2" name="st" required >
				<option >--ဆိုင်အမျိုးအစား ရွေးချယ်ပါ--</option>
				<option>ကုန်စုံဆိုင်</option>
				<option>ကုန်စိမ်းဆိုင်</option>
				<option>ကုန်မျိုးဆုံဆိုင်</option>
				<option>ရေပိုက် နှင့် ဆက်စပ်ပစ္စည်းဆိုင်</option>
				<option>စက်မှု့ပစ္စည်းဆိုင်</option>
				<option>အီလက်ထရောနစ်ဆိုင်</option>
				<option>ဆန်ဆိုင်</option>
				</select>
                <input type="text" class="form-control mt-2" name="ph" placeholder="ဖုန်းနံပါတ်" required >
                <select class="form-control mt-2" name="nr" required >
				
					  <option >--နိုင်ငံသား အမှတ် ရွေးချယ်ပါ--</option>
					  <option>၁/မကန(နိုင်)</option>
<option>၁/ဝမန(နိုင်)</option>
<option>၁/ခဖန(နိုင်)</option>
<option>၁/ဆလန(နိုင်)</option>
<option>၁/တနန(နိုင်)</option>
<option>၁/အဂယ(နိုင်)</option>
<option>၁/မညန(နိုင်)</option>
<option>၁/မကန(နိုင်)</option>
<option>၁/ကမန(နိုင်)</option>
<option>၁/ဗမန(နိုင်)</option>
<option>၁/ရကန(နိုင်)</option>
<option>၁/မစန(နိုင်)</option>
<option>၁/မမန(နိုင်)</option>
<option>၁/ပတအ(နိုင်)</option>
<option>၁/ဆပဘ(နိုင်)</option>
<option>၁/မခဘ(နိုင်)</option>
<option>၁/ခဘဒ(နိုင်)</option>
<option>၁/နမန(နိုင်)</option>
<option>၂/လကန(နိုင်)</option>
<option>၂/ဒမဆ(နိုင်)</option>
<option>၂/ဖရဆ(နိုင်)</option>
<option>၂/ရတန(နိုင်)</option>
<option>၂/ဘလခ(နိုင်)</option>
<option>၂/မစန(နိုင်)</option>
<option>၂/ဖဆန(နိုင်)</option>
<option>၃/ဘအန(နိုင်)</option>
<option>၃/လဘန(နိုင်)</option>
<option>၃/သတန(နိုင်)</option>
<option>၃/ကကရ(နိုင်)</option>
<option>၃/ကဆက(နိုင်)</option>
<option>၃/မဝတ(နိုင်)</option>
<option>၃/ဖပန(နိုင်)</option>
<option>၄/ဟခန(နိုင်)</option>
<option>၄/ထတလ(နိုင်)</option>
<option>၄/မတန(နိုင်)</option>
<option>၄/ပလဝ(နိုင်)</option>
<option>၄/မတပ(နိုင်)</option>
<option>၄/ကပလ(နိုင်)</option>
<option>၄/ဖလန(နိုင်)</option>
<option>၄/တတန(နိုင်)</option>
<option>၄/တဇန(နိုင်)</option>
<option>၅/မရန(နိုင်)</option>
<option>၅/အရတ(နိုင်)</option>
<option>၅/ခဥတ(နိုင်)</option>
<option>၅/ဘတလ(နိုင်)</option>
<option>၅/စကန(နိုင်)</option>
<option>၅/မမန(နိုင်)</option>
<option>၅/မမတ(နိုင်)</option>
<option>၅/ကလထ(နိုင်)</option>
<option>၅/ကလဝ(နိုင်)</option>
<option>၅/မကန(နိုင်)</option>
<option>၅/ကသန(နိုင်)</option>
<option>၅/အတန(နိုင်)</option>
<option>၅/ဗမန(နိုင်)</option>
<option>၅/ကလတ(နိုင်)</option>
<option>၅/ပလဘ(နိုင်)</option>
<option>၅/ဝသန(နိုင်)</option>
<option>၅/ထခန(နိုင်)</option>
<option>၅/ခတန(နိုင်)</option>
<option>၅/ဟမလ(နိုင်)</option>
<option>၅/လရန(နိုင်)</option>
<option>၅/နယန(နိုင်)</option>
<option>၅/လဟန(နိုင်)</option>
<option>၅/မလန(နိုင်)</option>
<option>၅/ဖပန(နိုင်)</option>
<option>၅/ယမပ(နိုင်)</option>
<option>၅/ဆလက(နိုင်)</option>
<option>၅/ပလန(နိုင်)</option>
<option>၅/ကနန(နိုင်)</option>
<option>၅/ရဘန(နိုင်)</option>
<option>၅/ဒပယ(နိုင်)</option>
<option>၅/ကဘလ(နိုင်)</option>
<option>၅/ခဥန(နိုင်)</option>
<option>၅/ကလန(နိုင်)</option>
<option>၅/တဆန(နိုင်)</option>
<option>၅/ရဥန(နိုင်)</option>
<option>၅/ဝလန(နိုင်)</option>
<option>၅/တမန(နိုင်)</option>
<option>၆/ထဝန(နိုင်)</option>
<option>၆/လလန(နိုင်)</option>
<option>၆/သရခ(နိုင်)</option>
<option>၆/ရဖန(နိုင်)</option>
<option>၆/မမန(နိုင်)</option>
<option>၆/တသရ(နိုင်)</option>
<option>၆/ကစန(နိုင်)</option>
<option>၆/ပလန(နိုင်)</option>
<option>၆/ကသန(နိုင်)</option>
<option>၆/ဘပန(နိုင်)</option>
<option>၇/ပခန(နိုင်)</option>
<option>၇/ဒဥန(နိုင်)</option>
<option>၇/ကတခ(နိုင်)</option>
<option>၇/ကဝန(နိုင်)</option>
<option>၇/ညလပ(နိုင်)</option>
<option>၇/ရကန(နိုင်)</option>
<option>၇/သနပ(နိုင်)</option>
<option>၇/ဝမန(နိုင်)</option>
<option>၇/ပမန(နိုင်)</option>
<option>၇/ပတန(နိုင်)</option>
<option>၇/သကန(နိုင်)</option>
<option>၇/ပခတ(နိုင်)</option>
<option>၇/ပတတ(နိုင်)</option>
<option>၇/ရတန(နိုင်)</option>
<option>၇/သဝတ(နိုင်)</option>
<option>၇/မညန(နိုင်)</option>
<option>၇/အဖန(နိုင်)</option>
<option>၇/လပတ(နိုင်)</option>
<option>၇/မလန(နိုင်)</option>
<option>၇/နတလ(နိုင်)</option>
<option>၇/ဇကန(နိုင်)</option>
<option>၇/ကပက(နိုင်)</option>
<option>၇/တငန(နိုင်)</option>
<option>၇/ထတပ(နိုင်)</option>
<option>၇/ဖမန(နိုင်)</option>
<option>၇/အတန(နိုင်)</option>
<option>၇/ရတရ(နိုင်)</option>
<option>၇/ကကန(နိုင်)</option>
<option>၈/မကန(နိုင်)</option>
<option>၈/နမန(နိုင်)</option>
<option>၈/မသန(နိုင်)</option>
<option>၈/တတက(နိုင်)</option>
<option>၈/ရနခ(နိုင်)</option>
<option>၈/ခမန(နိုင်)</option>
<option>၈/မဘန(နိုင်)</option>
<option>၈/ပဖန(နိုင်)</option>
<option>၈/ငဖန(နိုင်)</option>
<option>၈/စလန(နိုင်)</option>
<option>၈/စတရ(နိုင်)</option>
<option>၈/ဂဂန(နိုင်)</option>
<option>၈/ထလန(နိုင်)</option>
<option>၈/ဆမန(နိုင်)</option>
<option>၈/သရန(နိုင်)</option>
<option>၈/ဆပဝ(နိုင်)</option>
<option>၈/မတန(နိုင်)</option>
<option>၈/အလန(နိုင်)/မထန(နိုင်)</option>
<option>၈/မလန(နိုင်)</option>
<option>၈/ကမန(နိုင်)</option>
<option>၈/ပခက(နိုင်)</option>
<option>၈/ဆဖန(နိုင်)</option>
<option>၈/ပမန(နိုင်)</option>
<option>၈/မမန(နိုင်)</option>
<option>၈/ရစက(နိုင်)</option>
<option>၉/အမဇ(နိုင်)</option>
<option>၉/ခအဇ(နိုင်)</option>
<option>၉/ခမစ(နိုင်)</option>
<option>၉/မဟမ(နိုင်)</option>
<option>၉/ပကခ(နိုင်)</option>
<option>၉/ပသက(နိုင်)</option>
<option>၉/အမရ(နိုင်)</option>
<option>၉/ကဆန(နိုင်)</option>
<option>၉/မသန(နိုင်)</option>
<option>၉/စကတ(နိုင်)</option>
<option>၉/တတဥ(နိုင်)</option>
<option>၉/မထလ(နိုင်)</option>
<option>၉/မလန(နိုင်)</option>
<option>၉/သစန(နိုင်)</option>
<option>၉/ဝတန(နိုင်)</option>
<option>၉/မခန(နိုင်)</option>
<option>၉/နထက(နိုင်)</option>
<option>၉/ငဇန(နိုင်)</option>
<option>၉/တသန(နိုင်)</option>
<option>၉/ညဥန(နိုင်)</option>
<option>၉/ကပတ(နိုင်</option>
<option>၉/မမန(နိုင်)/ပဥလ(နိုင်)</option>
<option>၉/မကန(နိုင်)</option>
<option>၉/စကန(နိုင်)</option>
<option>၉/သပက(နိုင်)</option>
<option>၉/မတရ(နိုင်)</option>
<option>၉/ရမသ(နိုင်)</option>
<option>၉/ပဘန(နိုင်)</option>
<option>၉/ဒခသ(နိုင်)</option>
<option>၉/လဝန(နိုင်)</option>
<option>၉/ပမန(နိုင်)</option>
<option>၉/ဇဗသ(နိုင်)</option>
<option>၉/ဥတသ(နိုင်)</option>
<option>၉/ပဗသ(နိုင်)</option>
<option>၉/တကန(နိုင်)</option>
<option>၉/ဇယသ(နိုင်)</option>
<option>၁၀/မလမ(နိုင်)</option>
<option>၁၀/ရမန(နိုင်)</option>
<option>၁၀/ခဆန(နိုင်)</option>
<option>၁၀/ကမရ(နိုင်)</option>
<option>၁၀/မဒန(နိုင်)</option>
<option>၁၀/သဖရ(နိုင်)</option>
<option>၁၀/သထန(နိုင်)</option>
<option>၁၀/ဘလန(နိုင်)</option>
<option>၁၀/ကထန(နိုင်)</option>
<option>၁၀/ပမန(နိုင်)</option>
<option>၁၁/စတန(နိုင်)</option>
<option>၁၁/ပတန(နိုင်)</option>
<option>၁၁/ပဏတ(နိုင်)</option>
<option>၁၁/ရသတ(နိုင်)</option>
<option>၁၁/ကဖန(နိုင်)</option>
<option>၁၁/ရဗန(နိုင်)</option>
<option>၁၁/အမန(နိုင်)</option>
<option>၁၁/မအန(နိုင်)</option>
<option>၁၁/မဥန(နိုင်)</option>
<option>၁၁/မပတ(နိုင်)</option>
<option>၁၁/မပန(နိုင်)</option>
<option>၁၁/ကတန(နိုင်)</option>
<option>၁၁/သတန(နိုင်)</option>
<option>၁၁/တကန(နိုင်)</option>
<option>၁၁/ဂမန(နိုင်)</option>
<option>၁၁/မတန(နိုင်)</option>
<option>၁၁/ဘသတ(နိုင်)</option>
<option>၁၂/တမန(နိုင်)</option>
<option>၁၂/ဥကတ(နိုင်)</option>
<option>၁၂/ဒဂဆ(နိုင်)</option>
<option>၁၂/ဒဂတ(နိုင်)</option>
<option>၁၂/ဒဂမ(နိုင်)</option>
<option>၁၂/ဒဂရ(နိုင်)</option>
<option>၁၂/ဒပန(နိုင်)</option>
<option>၁၂/ပဇတ(နိုင်)</option>
<option>၁၂/ဗတထ(နိုင်)</option>
<option>၁၂/ဥကမ(နိုင်)</option>
<option>၁၂/ရကန(နိုင်)</option>
<option>၁၂/သဃက(နိုင်</option>
<option>၁၂/သကတ(နိုင်)</option>
<option>၁၂/မဂတ(နိုင်)</option>
<option>၁၂/တကန(နိုင်)</option>
<option>၁၂/ထတပ(နိုင်)</option>
<option>၁၂/မဂဒ(နိုင်)</option>
<option>၁၂/မဘန(နိုင်)</option>
<option>၁၂/ရပသ(နိုင်)</option>
<option>၁၂/လကန(နိုင်)</option>
<option>၁၂/လသယ(နိုင်)</option>
<option>၁၂/အစန(နိုင်)</option>
<option>၁၂/ကတန(နိုင်)</option>
<option>၁၂/ကခက(နိုင်)</option>
<option>၁၂/ကကက(နိုင်)</option>
<option>၁၂/ကမန(နိုင်)</option>
<option>၁၂/ခရန(နိုင်)</option>
<option>၁၂/ဆကခ(နိုင်)</option>
<option>၁၂/တတန(နိုင်)</option>
<option>၁၂/ဒလန(နိုင်)</option>
<option>၁၂/သလန(နိုင်)</option>
<option>၁၂/သခန(နိုင်)</option>
<option>၁၂/ကမရ(နိုင်)</option>
<option>၁၂/ကတတ(နိုင်)</option>
<option>၁၂/ကမတ(နိုင်)</option>
<option>၁၂/စခန(နိုင်)</option>
<option>၁၂/ဆကန(နိုင်)</option>
<option>၁၂/ဒဂန(နိုင်)</option>
<option>၁၂/ဗဟန(နိုင်)</option>
<option>၁၂/မရက(နိုင်)</option>
<option>၁၂/လမတ(နိုင်)</option>
<option>၁၂/လသန(နိုင်)</option>
<option>၁၂/လမန(နိုင်)</option>
<option>၁၂/အလန(နိုင်)</option>
<option>၁၂/ပဘတ(နိုင်)</option>
<option>၁၃/တကန(နိုင်)</option>
<option>၁၃/ဆဆန(နိုင်)</option>
<option>၁၃/ကလန(နိုင်)</option>
<option>၁၃/ရစန(နိုင်)</option>
<option>၁၃/ညရန(နိုင်)</option>
<option>၁၃/ပတယ(နိုင်)</option>
<option>၁၃/ပလန(နိုင်)</option>
<option>၁၃/ရငန(နိုင်)</option>
<option>၁၃/ဖခန(နိုင်)</option>
<option>၁၃/ဟပန(နိုင်)</option>
<option>၁၃/ကတန(နိုင်)</option>
<option>၁၃/မခန(နိုင်)</option>
<option>၁၃/မယန(နိုင်)</option>
<option>၁၃/မပတ(နိုင်)</option>
<option>၁၃/တခလ(နိုင်)</option>
<option>၁၃/မဖန(နိုင်)</option>
<option>၁၃/မယတ(နိုင်)</option>
<option>၁၃/ပယန(နိုင်)</option>
<option>၁၃/မမတ(နိုင်)</option>
<option>၁၃/မဘန(နိုင်)</option>
<option>၁၃/မဆန(နိုင်)</option>
<option>၁၃/မတန(နိုင်)</option>
<option>၁၃/မဆတ(နိုင်)</option>
<option>၁၃/ကခန(နိုင်)</option>
<option>၁၃/နခန(နိုင်)</option>
<option>၁၃/လခတ(နိုင်)</option>
<option>၁၃/မနန(နိုင်)</option>
<option>၁၃/မပန(နိုင်)</option>
<option>၁၃/မမန(နိုင်)</option>
<option>၁၃/လလန(နိုင်)</option>
<option>၁၃/ကဟန(နိုင်)</option>
<option>၁၃/လခန(နိုင်)</option>
<option>၁၃/မကန(နိုင်)</option>
<option>၁၃/မရန(နိုင်)</option>
<option>၁၃/ကသန(နိုင်)</option>
<option>၁၃/နစန(နိုင်)</option>
<option>၁၃/လရန(နိုင်)</option>
<option>၁၃/သနန(နိုင်)</option>
<option>၁၃/ကလန(နိုင်)</option>
<option>၁၃/မရတ(နိုင်)</option>
<option>၁၃/တယန(နိုင်)</option>
<option>၁၃/ကမန(နိုင်)</option>
<option>၁၃/သပန(နိုင်)</option>
<option>၁၃/မတတ(နိုင်)</option>
<option>၁၃/နဆန(နိုင်)</option>
<option>၁၃/နမတ(နိုင်)</option>
<option>၁၃/နခတ(နိုင်)</option>
<option>၁၃/လကန(နိုင်)</option>
<option>၁၃/ကကန(နိုင်)</option>
<option>၁၃/ဟပန(နိုင်)</option>
<option>၁၄/ပသန(နိုင်)</option>
<option>၁၄/ကကထ(နိုင်)</option>
<option>၁၄/ကပန(နိုင်)</option>
<option>၁၄/ငပတ(နိုင်)</option>
<option>၁၄/သပန(နိုင်)</option>
<option>၁၄/ကကန(နိုင်)</option>
<option>၁၄/ရကန(နိုင်)</option>
<option>၁၄/မအပ(နိုင်)</option>
<option>၁၄/ဓနဖ(နိုင်)</option>
<option>၁၄/ပတန(နိုင်)</option>
<option>၁၄/ညတန(နိုင်)</option>
<option>၁၄/ဟသတ(နိုင်)</option>
<option>၁၄/ဇလန(နိုင်)</option>
<option>၁၄/ကခန(နိုင်)</option>
<option>၁၄/မအန(နိုင်)</option>
<option>၁၄/အဂပ(နိုင်)</option>
<option>၁၄/လမန(နိုင်)</option>
<option>၁၄/မမန(နိုင်)</option>
<option>၁၄/ဝခမ(နိုင်)</option>
<option>၁၄/အမန(နိုင်)</option>
<option>၁၄/ဖပန(နိုင်)</option>
<option>၁၄/ဘကလ(နိုင်)</option>
<option>၁၄/ဒဒရ(နိုင်)</option>
<option>၁၄/ကလန(နိုင်)</option>
<option>၁၄/လပတ(နိုင်)</option>
<option>၁၄/မမက(နိုင်)</option>



</select>
					  </p>

				<input type="text" class="form-control mt-2" name="nr1" placeholder="မှတ်ပုံတင်အမှတ်-ဥပမာ-000112" required >
                <textarea type="text" class="form-control mt-2" name="ad" placeholder="နေရပ်လိပ်စာ" required ></textarea> 
            </div> </form> <div class="m-auto">

        <a href="conf.php"><input type="submit" name="sub2" class="btn mt-2 mr-auto" id="bt" value="ရှေဆက်ရန်"></a>

            </div>
    </div>
</form>





    <!----------------------------------------- link here ------------------------------------------------->
    <!-- bootstrap js -->
    <!--bootstrap js-->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

    <!-- fontawesome js-->
    <script src="all.js"></script>

    <!-- jquery -->
    <script src="js/jquery.min.js"></script>
    <script src="js/jquery-3.5.0.min.js"></script>
    <!------------------------------------------------ End -------------------------------------------------->

</body>

</html>