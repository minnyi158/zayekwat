
<?php
error_reporting(1);
session_start();
include("connection.php");
				$password=$_POST['ps'];
				$confirm=$_POST['co'];
	
		if(isset($_POST['sub12']))
							
					
							
					
						{
							if($password!=$confirm)
						{
							$err="* Please Re-check your password. Password Must be same";
							header("location:../psw.php?err=$err");
						}
						else
						{
							$q=mysqli_query($mysqli,"select * from register where nrc1='{$_SESSION[userid]}'");
							$r=mysqli_num_rows($q);
							if($r)
								{
									$err="<font color='red'>". $_SESSION['userid'] ."</font>Already Exists";
									header("location:../psw.php?err=$err");
								}
						
						else
							
						{		
								$q=mysqli_query($mysqli,"select * from register where phone='{$_SESSION[phone]}'");
								$r=mysqli_num_rows($q);
								if($r)
								{
									$err="<font color='red'> $phone </font>" ."Already Exists";
									header("location:../psw.php?err=$err");
								}
						
						else						
						{
										$request=$_SESSION['request'];
										$time=$_SESSION['time'];
										$userid=$_SESSION['userid'];
										$name=$_SESSION['name'];
										$shopname=$_SESSION['shopname'];
										$shoptype=$_SESSION['shoptype'];
										$phone=$_SESSION['phone'];
										$nrc=$_SESSION['nrc'];
										$nrc2=$_SESSION['nrc1'];
										$adress=$_SESSION['address'];
										$expire="7";
										$cost="Free";
										$amount="Free";
										$p_type="Trial";
										
									if(mysqli_query($mysqli,"INSERT INTO `register` (`id`, `date`, `time`, `userid`, `name`, `shopname`, `shoptype`, `phone`, `nrc`, `nrc1`, `adress`,`password`, `confirm`) VALUES
									(NULL,'$request','$time','$userid','$name','$shopname','$shoptype','$phone','$nrc','$nrc2','$adress','$password','$confirm')"))
									{
										
										$true="* success";
									header("location:packagelog.php?package_type=$p_type & cost=$cost & expire=$expire & amount=$amount");
										
									}
									else
									{
										$err="Sorry Something Went Wrong";
										header("location:../psw.php?err=$err");
									}
									
						}
					
										
					
								}
									}}
					
				
					
				
				
				
				
				


?>

