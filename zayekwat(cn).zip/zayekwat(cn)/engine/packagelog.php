

<?php
	error_reporting(1);
	Session_start();
	
	
	
			//$left=  " လူကြီးမင်း၏ ပက်ကေ့ချ်သက်တမ်း ကုန်ဆုံးရန် &nbsp <font color='green'><b>".round($date_diff, 0)."</b></font> &nbsp ရက်သာ လိုပါတော့သည်";
?>
			
<?php


			include("connection.php");
			$user_id="{$_SESSION[userid]}";
			$bankid="{$_GET[bankid]}";
			$bank_type="{$_GET[bank_type]}";
			$package_type="{$_GET[package_type]}";
			$expire3="{$_GET[expire]}";
			$cost="{$_GET[cost]}";
			$amount="{$_GET[amount]}";
			
			
	date_default_timezone_set('Asia/Rangoon');
	$script_tz = date_default_timezone_get();
	if(strcmp($script_tz, ini_get('date.timezone')))
	{
		$ans=date("h:i:sa");
		$request2=date('y-m-d');
	}
	else
	{
		echo 'Script timezone and ini-set timezone match.';
	}
	
	
	$sel="SELECT * FROM package_log WHERE user_id='$user_id'";
	$qry=mysqli_query($mysqli,$sel);
	$call=mysqli_fetch_array($qry);
	$call_id=$call['user_id'];
	$st_date=$call['start_date_time'];
	$ex_date=$call['expire_date_time'];
	$expire=$call['Packexpire'];
	$plus=$expire + $expire3;
	$exp=$plus;
	
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
			
			/*(For Insert)*/
		$timestamp = date('Y-m-d H:i:s');
		$start_date = date($timestamp);
		
		$expires = strtotime("+$exp days", strtotime($timestamp));
		//$expires = date($expires);

		$date_diff=($expires-strtotime($timestamp)) / 86400;

			$start=$timestamp;
			$end= date('Y-m-d H:i:s', $expires);
			$left= round($date_diff, 0);
			
	$message="Data Pack Activated! Price:$cost Kyat Data_type:$package_type Valid:$start Expire_Date:$end Check your balance under profile.
					Roll over the unused data by renewing pack before expiry.";
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	$import_info="INSERT INTO `customer_log` (`id`, `user_id`, `payment_type`, `tran_id`, `package_name`, `start_date_time`,
	`expire_date_time`,`Packexpire`,`cost`, `total`, `message`) VALUES (NULL, '$user_id', '$bank_type', '$bankid', '$package_type','$start', '$end', '$expire3', '$cost', '$amount','$message')";
	$cf=mysqli_query($mysqli,$import_info);
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	$check="SELECT user_id FROM package_log WHERE user_id='$user_id'";
	$qur=mysqli_query($mysqli,$check);
	if(mysqli_num_rows($qur))
		{
			if(mysqli_query($mysqli,"UPDATE package_log set start_date_time='$start',
			expire_date_time='$end', Packexpire='$exp' WHERE user_id='$user_id'"))
			
				{
					header("location:../index.php?name=$user_id & fromupdate");
				}
				
		}
		else
					{
					$li="INSERT INTO `package_log` (`id`, `user_id`, `start_date_time`, `expire_date_time`, `Packexpire`) 
					VALUES (NULL, '$user_id','$start', '$end', '$expire3')";
					$qr2=mysqli_query($mysqli,$li);
					header("location:../index.php?name=$user_id");
					}
	

?>

</br></br></br>