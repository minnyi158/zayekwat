<?php 
   $user='cp878677_pos';
   $password='MWTCpos2020@';
   $database='cp878677_pos';
   $mysqli = new mysqli('localhost',$user,$password,$database);
?>