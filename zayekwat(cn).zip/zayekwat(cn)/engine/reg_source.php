
<?php
error_reporting(1);
session_start();
include("connection.php");
date_default_timezone_set('Asia/Rangoon');
	$script_tz = date_default_timezone_get();
	if(strcmp($script_tz, ini_get('date.timezone')))
	{
		$ans=date("h:i:sa");
		$request2=date('d-m-y');
	}
	else
	{
		echo 'Script timezone and ini-set timezone match.';
	}
				
				$request=date('d-m-y');
				$time=date("h:i:sa");
				$first_name=rand(100,9999);
				$nrc1=$_POST['nr'];
				$nrc=$_POST['nr1'];
				
				$merger2="$nrc1$nrc";
				$nrc2=$merger2;
				$merge="mz$first_name$nrc";
				$userid=$merge;
				$name=$_POST['us'];
				$shopname=$_POST['sp'];
				$shoptype=$_POST['st'];
				$phone=$_POST['ph'];
				
				
				$adress=$_POST['ad'];
				$login=$_POST['lg'];
				
	
		if(isset($_POST['sub2']))
				{ 
								
						$q=mysqli_query($mysqli,"select * from register where nrc1='$nrc2'");
								$r=mysqli_num_rows($q);
								if($r)
								{
									$result="<font color='red'> $nrc </font>" ."Already Exists";
								}
						else
							
						{		
								$q=mysqli_query($mysqli,"select * from register where phone='$phone'");
								$r=mysqli_num_rows($q);
								if($r)
								{
									$result="<font color='red'> $phone </font>" ."Already Exists";
								}
								else
								{
									//if(mysqli_query($mysqli,"INSERT INTO `register` (`id`, `date`, `time`, `userid`, `name`, `shopname`, `shoptype`, `phone`, `nrc`, `nrc1`, `adress`,`password`, `confirm`) VALUES
									//(NULL,'$request','$time','$userid','$name','$shopname','$shoptype','$phone','$nrc','$nrc1','$adress','','')"))

									
										$_SESSION['request']=$request;
										$_SESSION['time']=$time;
										$_SESSION['userid']=$userid;
										$_SESSION['name']=$name;
										$_SESSION['shopname']=$shopname;
										$_SESSION['shoptype']=$shoptype;
										$_SESSION['phone']=$phone;
										$_SESSION['nrc']=$nrc;
										$_SESSION['nrc1']=$nrc2;
										$_SESSION['address']=$adress;
										$_SESSION['app_aut']=$_POST['sub2'];
										header("location:../code_aut.php?code_master_by_mwtc");										
								}
					
						}
					}
				
				
				
				
				


?>

