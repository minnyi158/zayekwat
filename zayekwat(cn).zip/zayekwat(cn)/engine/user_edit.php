<?php
include("connection.php");
    $name = $_POST['name'];
    $phone = $_POST['phone'];

    $sql = "UPDATE register SET name='$name', phone= '$phone'";

    mysqli_query($mysqli,$sql);
    header("location: ../index.php");


?>