
<?php
error_reporting(1);
session_start();
include("connection.php");
	date_default_timezone_set('Asia/Rangoon');
	$script_tz = date_default_timezone_get();
	if(strcmp($script_tz, ini_get('date.timezone')))
	{
		$ans=date("h:i:sa");
		$request2=date('d-m-y');
	}
	else
	{
		echo 'Script timezone and ini-set timezone match.';
	}
	$request=date("h:i:sa");
	$log="Dear Customer we noticed that at". $request2 ."$request";
	$request2=date('d-m-y');
	$data20=$_POST['data20'];
	$data21=$_POST['data21'];
	
	$data="SELECT * FROM register where phone='$data20' and password='$data21'";
	$val=mysqli_query($mysqli,$data);
	$arr=mysqli_fetch_array($val);
	$userid3=$arr['userid'];
	
	
	if(isset($_POST['sub11']))
	
	{	
								$q=mysqli_query($mysqli,"select phone from register where phone='$data20'");
								$r=mysqli_num_rows($q);
								if(!$r)
								{
									$err="$data20 is not registered Yet.";
									header("location:../login.php?err=$err");
								}
								else
								{
		$data="SELECT * FROM register where phone='$data20' and password='$data21'";
		$val=mysqli_query($mysqli,$data);
		if(mysqli_fetch_array($val))
		{
			$qryy="INSERT INTO login_log(id,phnb,log)
					VALUES(NULL,'$data20','$log')";
					$result=mysqli_query($mysqli,$qryy) or die ("save items query fail.");
					$_SESSION['ph']=$data20;
					$_SESSION['app_aut']=$_POST['sub11'];
					$_SESSION['userid']=$userid3;
			echo "Success";
			header("location:../index.php?name=$userid3");
		}
		else
		{
			$err=" Please Check Your Ph & PW";
			header("location:../login.php?err=$err");
		}
	

	}
	}


?>



