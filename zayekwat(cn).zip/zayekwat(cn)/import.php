<?php 
	error_reporting(1);
	session_start();
	include("engine/connection.php");
	if(!isset($_SESSION['app_aut']))
	{
		$err="အသုံးပြုရန် ပထမဦးစွာ စီစစ်ခံရန်လိုအပ်ပါသည်။";
		header("location:login.php?err=$err");
	}
	else
	{
		
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ZayeKwat</title>
    <!--font awesome css-->
    <link rel="stylesheet" href="./css/all.css">

    <!--bootstrap css-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <!--my css-->
    <link rel="stylesheet" href="css/main.css">
    <link href="css/simple-sidebar.css" rel="stylesheet">
    <!--google font-->
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@100&display=swap" rel="stylesheet">

</head>

<body>




  <!-- Use any element to open the sidenav -->

    <!-- Sidebar -->
	<?php

					 error_reporting(1);
					 session_start();
					 include("engine/connection.php");
					 
						$query=mysqli_query($mysqli,"SELECT * FROM register WHERE userid='{$_SESSION['userid']}'");
						while($submit=mysqli_fetch_array($query))
							{		
									$id=$submit['ID'];					
									$na=$submit['name'];
									$_SESSION['name']=$na;
							}
								
									
							
?>

    <div class="d-flex " id="wrapper">
        <div class=" border-right side" id="sidebar-wrapper">

            <div class="list-group list-group-flush p-3 m-auto">
                <a class="navbar-brand text-center" href="#" class="list-group-item list-group-item-action center">
                    <img src="image/icon1.png" alt="" width="80px" height="80px" class="img-thumbnail rounded-circle mt-2">
                    <div style="color: black;" class="text-center"><?php error_reporting(1); echo $na; ?></div>
                </a>
                <span class="list-group-item list-group-item-action"> <?php echo date("d/ m / yy") ?></span>
                <a href="index.php" class="list-group-item list-group-item-action">ပရိုဖိုင်</a>
               
                     <button type="button" class="list-group-item list-group-item-action" data-toggle="modal" data-target="#exampleModal1">
                                <span>၀န်ဆောင်မှူများ</span>
                            </button>
                
               
                <a href="import.php" class="list-group-item list-group-item-action">သွင်းကုန်</a>
                <a href="export.php" class="list-group-item list-group-item-action">ပို့ကုန်</a>
                <a href="#" class="list-group-item list-group-item-action">ငွေကြေးမှတ်တမ်းများ</a>
                <a href="#" class="list-group-item list-group-item-action">ငွေကြေးလဲလှယ်နှုန်း</a>
                <a href="#" class="list-group-item list-group-item-action">အကူအညီ</a>
                <a href="#" class="list-group-item list-group-item-action ">အသုံးပြုပုံ</a>
                <a href="logout.php" class="list-group-item list-group-item-action ">ထွက်ခွာရန်</a>

            </div>
        </div>
        <!-- /#sidebar-wrapper -->



        <!-- /#page-content-wrapper -->
        <div id="page-content-wrapper">
            

            <section class="container-fluid fixed-top mt-4 shadow p-3 mb-5 bg-white rounded nav_sec">
                <div class="row">


                    <div class="col col-sm-3 text-center border-right"><button class="btn " id="menu-toggle"> <i class=" fa fa-bars" aria-hidden="true"></i><span><font size="3"> မီနူး</font></span></button> </div>
                    <div class="col col-sm-3 text-center border-right"> <a href="index.php" class="btn "><i class=" fa fa-home" aria-hidden="true"></i><span><font size="3">ပင်မ</font> </span></span></a></div>
                    <div class="col col-sm-3 text-center border-right "><a href="cart.php" class="btn "><i class="fa fa-shopping-cart"></i><span ><font size="3">ဈေးခြင်း</font> </span></a></div>

                        <!--  user edit   -->
                        <div class="col col-sm-3 text-center ">
                            <a href="#exampleModal" class="btn " data-toggle="modal" data-target="#exampleModal">
                                <i class="fa fa-user-cog"></i> <span>ပြင်ဆင်ရန် </span>
                            </a>
                        </div>
                        <!--  end  -->
                </div>
                <nav class="navbar   navclass fixed-top">

                <p align="center"></p><a class="" href="index.php">
                    <img src="image/logo1.png" height="70px" class="" alt="">
                </a></p>
                <div class="icon ml-auto"><a href=""><i class="fab fa-facebook-messenger"></i></a><a href="#"><i class="fa fa-bell" aria-hidden="true"></i></a></div>
            </nav>
            </section>


            <!-- /#wrapper -->

            <!--- page contant---->

      <div class="container main text-left">
             <div class="row">
           
			<?php 
			error_reporting(1);
			session_start();
			include("engine/connection.php");
			$user_id="{$_SESSION[userid]}";
			$check="SELECT user_id FROM package_log WHERE user_id='$user_id'";
			$qur=mysqli_query($mysqli,$check);
			if(!mysqli_num_rows($qur))
			{
				echo "</br></br></br></br>";
				echo "ဝမ်းနည်းပါတယ်။ လူကြီးမင်း၏ လက်ကျန်သက်တမ်း မရှိတော့ပါ။ ဆက်လက် အသုံးပြုနိုင်ရန် သက်တမ်းတိုးမည် ကိုနှိပ်ပါ။ </br></br>";
				echo"<p align='center'><a href='package.php'><button type='button' class='btn btn-primary m-auto'>သက်တမ်းတိုးမည် </button></a></p>";
			}
			else
			{
			
			?>
			 
               
                    
                           
                        <div class="card col-sm-3 col-md-3 col-lg-3 mb mr-auto ml-auto shadow p-3 mb-5 bg-white rounded" style="width: 13rem;">
                                <img class="card-img-top" src="image/gf1.gif" height="120px" alt="Card image cap">
                            <div class="card-body">
                                <p class="card-text" >အမျိုးအစား =  <br>လက်ကျန် =   <br> ဈေးနှုန်း = </p>
                                <button type="button" class="btn btn-primary m-auto" data-toggle="modal" data-target="#exampleModal1">
                                <span><i class="fas fa-tools"></i><font size="1">ပြင်ဆင်မည်</font></span>
                                </button>
                                 <a href="#" class="btn btn-primary">
                                <span><i class="far fa-trash-alt"></i><font size="1">ဖျက်မည်</font></span>
                                </a>
                            </div>
                        </div>
                        
                        <div class="card col-sm-3 col-md-3 col-lg-3 mb mr-auto ml-auto shadow p-3 mb-5 bg-white rounded" style="width: 13rem;">
                                <img class="card-img-top" src="image/gf2.gif" height="120px" alt="Card image cap">
                            <div class="card-body">
                                <p class="card-text" >အမျိုးအစား =  <br>လက်ကျန် =   <br> ဈေးနှုန်း = </p>
                                <button type="button" class="btn btn-primary m-auto" data-toggle="modal" data-target="#exampleModal1">
                                <span><i class="fas fa-tools"></i><font size="1">ပြင်ဆင်မည်</font></span>
                                </button>
                                 <a href="#" class="btn btn-primary">
                                <span><i class="far fa-trash-alt"></i><font size="1">ဖျက်မည်</font></span>
                                </a>
                            </div>
                        </div>
                       
                        <div class="card col-sm-3 col-md-3 col-lg-3 mb mr-auto ml-auto shadow p-3 mb-5 bg-white rounded" style="width: 13rem;">
                                <img class="card-img-top" src="image/gf3.gif" height="120px" alt="Card image cap">
                            <div class="card-body">
                                <p class="card-text" >အမျိုးအစား =  <br>လက်ကျန် =   <br> ဈေးနှုန်း = </p>
                                <button type="button" class="btn btn-primary m-auto" data-toggle="modal" data-target="#exampleModal1">
                                <span><i class="fas fa-tools"></i><font size="1">ပြင်ဆင်မည်</font></span>
                                </button>
                                 <a href="#" class="btn btn-primary">
                                <span><i class="far fa-trash-alt"></i><font size="1">ဖျက်မည်</font></span>
                                </a>
                            </div>
                        </div>


		<?php } 
			?>
                

              
         </div>
    </div>


            <!--footer bar-->
            <footer>
                <div class="container-fluid foot text-center">
                    Power By MWTC

                </div>
            </footer>

<div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModal1Label" aria-hidden="true">
					<div class="modal-dialog" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title" id="exampleModal1Label">သင်ဝယ်ယူခဲ့သည့်မှတ်တမ်းများ</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
							    
								<form action="#" method="post">
									<div class="alert alert-primary alert-dismissible fade show" role="alert">
									Edit List
									</div>
						

							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-secondary" data-dismiss="modal">ပြန်ထွက်ရန် </button>

							</div>
							</form>

						</div>
					</div>
				</div>
				
				


            <!--bootstrap js-->
            <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
            <!--fontawesome js-->
            <script src="./js/all.js"></script>

            <!--jquery-->
            <script src="./js/jquery-3.5.0.min.js"></script>
            <script src="./js/jquery.min.js"></script>
            <!--menu js-->

            <script>
                $("#menu-toggle").click(function(e) {
                    e.preventDefault();
                    $("#wrapper").toggleClass("toggled");
                });
            </script>

</body>

</html>
	<?php } ?>

<!--<script>
    $("#menu-toggle").click(function (e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>-->