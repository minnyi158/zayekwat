<?php
include("engine/connection.php");
session_start();
$result = mysqli_query($mysqli, "SELECT * FROM package_log ");
$row = mysqli_fetch_assoc($result);


?>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">၀ယ်ယူထားသည့် ဝန်ဆောင်မှု</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="engine/user_edit.php" method="post">
                    <div class="form-group">
                        <label for="my-input">အမည်</label>
                        <input id="my-input" class="form-control" type="text" name="name" value="<?php echo $row['user_id'];  ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="my-input">၀ယ်ယူသည့်ရက်/label>
                        <input id="my-input" class="form-control" type="text" name="name" value="<?php echo $row['Packexpire'];  ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="my-input">၀ယ်ယူသည့်ရက််</label>
                        <input id="my-input" class="form-control" type="text" name="phone" value="<?php echo $row['start_date_time']  ?>" readonly>
                    </div>
                     <div class="form-group">
                        <label for="my-input">ကုန်ဆုံးမည့်ချိန် </label>
                        <input id="my-input" class="form-control" type="text" name="phone" value="<?php echo $row['expire_date_time']  ?>" readonly>
                    </div>
                    
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">ပြန်ထွက်ရန် </button>
               
            </div>
            </form>

        </div>
    </div>
</div>