<?php 
	error_reporting(1);
	session_start();
	
	if(!isset($_SESSION['app_aut']))
	{
		$err="အသုံးပြုရန် ပထမဦးစွာ စီစစ်ခံရန်လိုအပ်ပါသည်။";
		header("location:login.php?err=$err");
	}
	else
	{
		
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!---- SEO ----->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
   

    <!------------------------------Css link here-------------------------------------->
    <!--Fontawesome Css-->
    <link rel=" stylesheet" href="css/all.css">

    <!--bootstrap Css-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <!-- w3-css -->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

    <!--- Css Style---->
    <link rel="stylesheet" href="css/main.css">
    <!-------------------------------------- End -------------------------------------------->

</head>


<body id="grad">

    <!--- login form ---->
<form method="post" action="engine/psw.php">
    <div class="container bg-light login-con p-5 rounded w3-animate-bottom shadow-lg p-3 mb-5 bg-white rounded">
        <form action="/home.php" class="login-form">
            <h2 class="form-login heading text-center">
                လျို့ဝှက်နံပါတ်ထည့်ရန်
            </h2>
            <div class="login-warp">
			<?php error_reporting(1); echo "{$_GET['err']}"; ?>
                <input type="text" class="form-control" name="ps" placeholder="လျို့ဝှက် နံပါတ် ထည့်ပါ " required >
                <input type="text" class="form-control mt-2" name="co" placeholder="နောက်တစ်ကြိမ်" required >
                

        <a href="conf.php"><input type="submit" name="sub12" class="btn mt-2 mr-auto" id="bt" value="ရှေဆက်ရန်"></a>

            </div>
    </div>
</form>





    <!----------------------------------------- link here ------------------------------------------------->
    <!-- bootstrap js -->
    <!--bootstrap js-->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

    <!-- fontawesome js-->
    <script src="all.js"></script>

    <!-- jquery -->
    <script src="js/jquery.min.js"></script>
    <script src="js/jquery-3.5.0.min.js"></script>
    <!------------------------------------------------ End -------------------------------------------------->

</body>

</html>
	<?php } ?>