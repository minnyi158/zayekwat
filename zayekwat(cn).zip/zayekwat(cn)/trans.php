<?php 
	error_reporting(1);
	session_start();
	include("engine/connection.php");
	if(!isset($_SESSION['app_aut']))
	{
		$err="အသုံးပြုရန် ပထမဦးစွာ စီစစ်ခံရန်လိုအပ်ပါသည်။";
		header("location:login.php?err=$err");
	}
	else
	{
		
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ZayeKwat</title>
    <!--font awesome css-->
    <link rel="stylesheet" href="./css/all.css">

    <!--bootstrap css-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <!--my css-->
    <link rel="stylesheet" href="css/main.css">
    <link href="css/simple-sidebar.css" rel="stylesheet">
    <!--google font-->
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@100&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  margin: 0 -16px;
}

.col-25 {
  -ms-flex: 25%; /* IE10 */
  flex: 25%;
}

.col-50 {
  -ms-flex: 50%; /* IE10 */
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; /* IE10 */
  flex: 75%;
}

.col-25,
.col-50,
.col-75 {
  padding: 0 16px;
}

.container {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
}

input[type=text] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;
}

.btn2 {
  background-color: #4CAF50;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn2:hover {
  background-color: #45a049;
}

span.price {
  float: right;
  color: grey;
}

/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (and change the direction - make the "cart" column go on top) */
@media (max-width: 800px) {
  .row {
    flex-direction: column-reverse;
  }
  .col-25 {
    margin-bottom: 20px;
  }
}
</style>

</head>

<body>

<?php
	error_reporting(1);
	session_start();
		
		$bank_id=$_POST['wallent_id'];
		$amount=$_POST['amount'];
		
		if(isset($_POST['send']))
			{
				header("location:engine/packagelog.php?package_type={$_GET['package_type']} & cost={$_GET['cost']} & expire={$_GET['expire']} & bankid=$bank_id & amount={$_GET['cost']}");
			}
			else
			{
				echo "Dead";
			}
?>


   <!-- Use any element to open the sidenav -->

    <!-- Sidebar -->
	<?php

					 error_reporting(1);
					 session_start();
					 include("engine/connection.php");
					 
						$query=mysqli_query($mysqli,"SELECT * FROM register WHERE userid='{$_SESSION['userid']}'");
						while($submit=mysqli_fetch_array($query))
							{		
									$id=$submit['ID'];					
									$na=$submit['name'];
									$_SESSION['name']=$na;
							}
								
									
							
?>

    <div class="d-flex " id="wrapper">
        <div class=" border-right side" id="sidebar-wrapper">

            <div class="list-group list-group-flush p-3 m-auto">
                <a class="navbar-brand text-center" href="#" class="list-group-item list-group-item-action center">
                    <img src="image/icon1.png" alt="" width="80px" height="80px" class="img-thumbnail rounded-circle mt-2">
                    <div style="color: black;" class="text-center"><?php error_reporting(1); echo $na; ?></div>
                </a>
                <span class="list-group-item list-group-item-action"> <?php echo date("d/ m / yy") ?></span>
                <a href="index.php" class="list-group-item list-group-item-action">ပရိုဖိုင်</a>
               
                     <button type="button" class="list-group-item list-group-item-action" data-toggle="modal" data-target="#exampleModal1">
                                <span>၀န်ဆောင်မှူများ</span>
                            </button>
                
               
                <a href="import.php" class="list-group-item list-group-item-action">သွင်းကုန်</a>
                <a href="export.php" class="list-group-item list-group-item-action">ပို့ကုန်</a>
                <a href="#" class="list-group-item list-group-item-action">ငွေကြေးမှတ်တမ်းများ</a>
                <a href="#" class="list-group-item list-group-item-action">ငွေကြေးလဲလှယ်နှုန်း</a>
                <a href="#" class="list-group-item list-group-item-action">အကူအညီ</a>
                <a href="#" class="list-group-item list-group-item-action ">အသုံးပြုပုံ</a>
                <a href="logout.php" class="list-group-item list-group-item-action ">ထွက်ခွာရန်</a>

            </div>
        </div>
        <!-- /#sidebar-wrapper -->



        <!-- /#page-content-wrapper -->
        <div id="page-content-wrapper">
            

            <section class="container-fluid fixed-top mt-4 shadow p-3 mb-5 bg-white rounded nav_sec">
                <div class="row">


                    <div class="col col-sm-3 text-center border-right"><button class="btn " id="menu-toggle"> <i class=" fa fa-bars" aria-hidden="true"></i><span><font size="3"> မီနူး</font></span></button> </div>
                    <div class="col col-sm-3 text-center border-right"> <a href="index.php" class="btn "><i class=" fa fa-home" aria-hidden="true"></i><span><font size="3">ပင်မ</font> </span></span></a></div>
                    <div class="col col-sm-3 text-center border-right "><a href="cart.php" class="btn "><i class="fa fa-shopping-cart"></i><span ><font size="3">ဈေးခြင်း</font> </span></a></div>

                        <!--  user edit   -->
                        <div class="col col-sm-3 text-center ">
                            <a href="#exampleModal" class="btn " data-toggle="modal" data-target="#exampleModal">
                                <i class="fa fa-user-cog"></i> <span>ပြင်ဆင်ရန် </span>
                            </a>
                        </div>
                        <!--  end  -->
                </div>
                <nav class="navbar   navclass fixed-top">

                <p align="center"></p><a class="" href="index.php">
                    <img src="image/logo1.png" height="70px" class="" alt="">
                </a></p>
                <div class="icon ml-auto"><a href=""><i class="fab fa-facebook-messenger"></i></a><a href="#"><i class="fa fa-bell" aria-hidden="true"></i></a></div>
            </nav>
            </section>
			



            <!-- /#wrapper -->

            <!--- page contant---->
<div class="container main text-left">
<div class="row">
  <div class="col-75">
    <div class="container">
      <form method="post">

        <div class="row">
          <div class="col-50">
            <h3>ငွေတောင်းခံရန်လိပ်စာ</h3>
            <label for="fname"><i class="fa fa-user"></i> နာမည်အပြည့်အစုံ</label>
            <input type="text" id="fname" name="firstname" placeholder="John M. Doe" disabled >
            <label for="email"><i class="fa fa-envelope"></i> အီးမေလ်း</label>
            <input type="text" id="email" name="email" placeholder="john@example.com" disabled >
            <label for="adr"><i class="fa fa-address-card-o"></i> နေရပ်လိပ်စာ</label>
            <input type="text" id="adr" name="address" placeholder="542 W. 15th Street" disabled >
            <label for="city"><i class="fa fa-institution"></i> နေထိုင်သည့် မြို့နယ်</label>
            <input type="text" id="city" name="city" placeholder="New York" disabled >

            <div class="row">
              <div class="col-50">
                <label for="state">တိုင်းဒေသကြီး</label>
                <input type="text" id="state" name="state" placeholder="NY" disabled >
              </div>
              <div class="col-50">
                <label for="zip">ဧရိယာကုဒ္</label>
                <input type="text" id="zip" name="zip" placeholder="10001" disabled >
              </div>
            </div>
          </div>

          <div class="col-50">
            <h3>ငွေပေးချေမှု</h3>
            <label for="fname">လက်ခံသည့်ကဒ်များ</label>
            <div class="icon-container">
              <i class="fa fa-cc-visa" style="color:navy;"></i>
              <i class="fa fa-cc-amex" style="color:blue;"></i>
              <i class="fa fa-cc-mastercard" style="color:red;"></i>
              <i class="fa fa-cc-discover" style="color:orange;"></i>
            </div>
            <label for="cname">ကဒ်ပေါ်မှ နာမည်</label>
            <input type="text" id="cname" name="cardname" placeholder="John More Doe" disabled >
            <label for="ccnum">ခရက်ဒစ်ကဒ်နံပါတ်</label>
            <input type="text" id="ccnum" name="wallent_id" placeholder="1111-2222-3333-4444">
            <label for="expmonth">ကုန်ဆုံးမည့်ရက်</label>
            <input type="text" id="expmonth" name="expmonth" placeholder="September" disabled >

            <div class="row">
              <div class="col-50">
                <label for="expyear">ကုန်ဆုံးမည့်နှစ်</label>
                <input type="text" id="expyear" name="expyear" placeholder="2018" disabled >
              </div>
              <div class="col-50">
                <label for="cvv">CVV</label>
                <input type="text" id="cvv" name="cvv" placeholder="352" disabled >
              </div>
            </div>
          </div>

        </div>
        <label>
          <input type="checkbox" checked="checked" name="sameadr" disabled > ငွေတောင်းခံအဖြစ်လိပ်စာကိုတင်ပို့ပါ
        </label>
        <input type="submit" name="send" value="ငွေပေးချေခြင်းကို ဆက်လက်ဆောင်ရွက်ပါ" class="btn2">
      </form>
    </div>
  </div>

  <div class="col-25">
    <div class="container">
      <h4>Cart
        <span class="price" style="color:black">
          <i class="fa fa-shopping-cart"></i>
         
        </span>
      </h4>
      <p><a href="#">ကျသင့်ငွေ</a> <span class="price"><?php error_reporting(1); echo "{$_GET['cost']}";  ?></span></p>
      
      <hr>
      <p>ကျသင့်ငွေစုစုပေါင်း <span class="price" style="color:black"><b><?php error_reporting(1); echo "{$_GET['cost']}";  ?></b></span></p>
    </div>
  </div>
</div></div>

           


            <!-----end------>


            <!--footer bar-->
            <footer>
                <div class="container-fluid foot text-center">
                    Power By MWTC

                </div>
            </footer>

            <!--bootstrap js-->
            <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
            <!--fontawesome js-->
            <script src="./js/all.js"></script>

            <!--jquery-->
            <script src="./js/jquery-3.5.0.min.js"></script>
            <script src="./js/jquery.min.js"></script>
            <!--menu js-->

            <script>
                $("#menu-toggle").click(function(e) {
                    e.preventDefault();
                    $("#wrapper").toggleClass("toggled");
                });
            </script>

</body>

</html>
	<?php } ?>			
<!--<script>
    $("#menu-toggle").click(function (e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>-->