<?php 
	error_reporting(1);
	session_start();
	
	if(!isset($_SESSION['app_aut']))
	{
		$err="အသုံးပြုရန် ပထမဦးစွာ စီစစ်ခံရန်လိုအပ်ပါသည်။";
		header("location:login.php?err=$err");
	}
	else
	{
		
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ZayeKwat</title>
    <!--font awesome css-->
    <link rel="stylesheet" href="./css/all.css">

    <!--bootstrap css-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <!--my css-->
    <link rel="stylesheet" href="css/main.css">
    <link href="css/simple-sidebar.css" rel="stylesheet">
    <!--google font-->
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@100&display=swap" rel="stylesheet">


</head>

<body>




    <!-- Use any element to open the sidenav -->

    <!-- Sidebar -->
	<?php

					 error_reporting(1);
					 session_start();
					 include("engine/connection.php");
					 
						$query=mysqli_query($mysqli,"SELECT * FROM register WHERE userid='{$_SESSION['userid']}'");
						while($submit=mysqli_fetch_array($query))
							{		
									$id=$submit['ID'];					
									$na=$submit['name'];
									$_SESSION['name']=$na;
							}
								
									
							
?>

    <div class="d-flex " id="wrapper">
        <div class=" border-right side" id="sidebar-wrapper">

            <div class="list-group list-group-flush p-3 m-auto">
                <a class="navbar-brand text-center" href="#" class="list-group-item list-group-item-action center">
                    <img src="image/icon1.png" alt="" width="80px" height="80px" class="img-thumbnail rounded-circle mt-2">
                    <div style="color: black;" class="text-center"><?php error_reporting(1); echo $na; ?></div>
                </a>
                <span class="list-group-item list-group-item-action"> <?php echo date("d/ m / yy") ?></span>
                <a href="index.php" class="list-group-item list-group-item-action">ပရိုဖိုင်</a>
               
                     <button type="button" class="list-group-item list-group-item-action" data-toggle="modal" data-target="#exampleModal1">
                                <span>၀န်ဆောင်မှူများ</span>
                            </button>
                
               
                <a href="import.php" class="list-group-item list-group-item-action">သွင်းကုန်</a>
                <a href="export.php" class="list-group-item list-group-item-action">ပို့ကုန်</a>
                <a href="#" class="list-group-item list-group-item-action">ငွေကြေးမှတ်တမ်းများ</a>
                <a href="#" class="list-group-item list-group-item-action">ငွေကြေးလဲလှယ်နှုန်း</a>
                <a href="#" class="list-group-item list-group-item-action">အကူအညီ</a>
                <a href="#" class="list-group-item list-group-item-action ">အသုံးပြုပုံ</a>
                <a href="logout.php" class="list-group-item list-group-item-action ">ထွက်ခွာရန်</a>

            </div>
        </div>
        <!-- /#sidebar-wrapper -->



        <!-- /#page-content-wrapper -->
        <div id="page-content-wrapper">
            

            <section class="container-fluid fixed-top mt-4 shadow p-3 mb-5 bg-white rounded nav_sec">
                <div class="row">


                    <div class="col col-sm-3 text-center border-right"><button class="btn " id="menu-toggle"> <i class=" fa fa-bars" aria-hidden="true"></i><span><font size="3"> မီနူး</font></span></button> </div>
                    <div class="col col-sm-3 text-center border-right"> <a href="index.php" class="btn "><i class=" fa fa-home" aria-hidden="true"></i><span><font size="3">ပင်မ</font> </span></span></a></div>
                    <div class="col col-sm-3 text-center border-right "><a href="cart.php" class="btn "><i class="fa fa-shopping-cart"></i><span ><font size="3">ဈေးခြင်း</font> </span></a></div>

                        <!--  user edit   -->
                        <div class="col col-sm-3 text-center ">
                            <a href="#exampleModal" class="btn " data-toggle="modal" data-target="#exampleModal">
                                <i class="fa fa-user-cog"></i> <span>ပြင်ဆင်ရန် </span>
                            </a>
                        </div>
                        <!--  end  -->
                </div>
                <nav class="navbar   navclass fixed-top">

                <p align="center"></p><a class="" href="index.php">
                    <img src="image/logo1.png" height="70px" class="" alt="">
                </a></p>
                <div class="icon ml-auto"><a href=""><i class="fab fa-facebook-messenger"></i></a><a href="#"><i class="fa fa-bell" aria-hidden="true"></i></a></div>
            </nav>
            </section>



            <!-- /#wrapper -->

            <!--- page contant---->
<?php
error_reporting(1);
session_start();

		date_default_timezone_set('Asia/Rangoon');
		$script_tz = date_default_timezone_get();
		if(strcmp($script_tz, ini_get('date.timezone')))
		{
		$timestamp = date('Y-m-d H:i:s');
		if(!date('$timestamp'))
		{
		echo "ဝမ်းနည်းပါတယ်။  လူကြီးမင်း အသုံးပြုသော စက်တွင် ရက်စွဲ နှင့် နာရီ သည် သတ်မှတ်ဧရိယာကျော်လွန်နေပါ ၍ လက်တစ်လောတွင် အသုံးပြု၍ မရနိုင်ပါ။ ပြန်လည်ပြင်ဆင်ပြီးမှ ထပ်မံကြိုးစားကြည့်ပါ။";
		$request2=date('d-m-y');
		}
		else
		{
		
?>

            <div class="container main text-left">
                <div class="row">
				<?php

					 error_reporting(1);
					 session_start();
					 include("engine/connection.php");
					 
						$query=mysqli_query($mysqli,"SELECT * FROM register WHERE userid='{$_SESSION['userid']}'");
						while($submit=mysqli_fetch_array($query))
							{		
									$id=$submit['ID'];					
									$na=$submit['name'];
									$ui=$submit['userid'];
									$sh=$submit['shopname'];
									$st=$submit['shoptype'];
									$mb=$submit['phone'];
									$nr=$submit['nrc'];
									$nr1=$submit['nrc1'];
									$ad=$submit['adress'];
									$_SESSION['usname']=$na;
								
									
							
?>
                    <div class="card col-sm-5 col-md-4 col-lg-4 mb mr-auto ml-auto shadow p-3 mb-5 bg-white rounded" style="width: 18rem;">
                        <div class="card-body bd">
                            <h5 class="card-title">အသုံးပြုသူ အချက်အလက်များ</h5>
							<hr>
                            <p class="card-text">အမည် &emsp;&emsp;&emsp;&emsp;&emsp;:</br><span><?php error_reporting(1); echo"$na"; ?>"</span></p>
                            <p class="card-text">လုပ်ငန်းစဉ်အမှတ် &nbsp; :</br><span><?php error_reporting(1); echo"$ui"; ?></span></p>
                            <p class="card-text">ဆိုင်အမည် &emsp;&emsp;&nbsp;:</br><span> <?php error_reporting(1); echo"$sh/$st"; ?></span></p>
							<p class="card-text">မှတ်ပုံတင်အမှတ် &nbsp;:</br><span> <?php error_reporting(1); echo" $nr1"; ?></span></p>
							


                        </div>
                    </div>
							<?php } ?>
							
					<div class="card col-sm-5 col-md-4 col-lg-3 mb mr-auto ml-auto shadow p-3 mb-5 bg-white rounded" style="width: 18rem;">
                        <div class="card-body bd ">
                            <h5 class="card-title ">ကုန်ပစ္စည်းများတင်ရန်</h5>
                            <hr></br>
                            <button type="button" class="btn btn-primary m-auto" data-toggle="modal" data-target="#exampleModal3" ><i class="fas fa-upload"></i>ကုန်စိမ်း -</button><br><br><hr>
							 <button type="button" class="btn btn-primary m-auto" data-toggle="modal" data-target="#exampleModal4">
                                <i class="fas fa-upload"></i><span>ကုန်ခြောက်</span>
                                </button>
                        </div>
                    </div>
					<?php
error_reporting(1);
include("connection.php");
session_start();
$user_id="{$_SESSION[userid]}";
	$sel="SELECT * FROM package_log WHERE user_id='$user_id'";
	$qry=mysqli_query($mysqli,$sel);
	$call=mysqli_fetch_array($qry);
	$userid=$call['user_id'];
	$st_date=$call['start_date_time'];
	$ex_date=$call['expire_date_time'];
	$exp=$call['Packexpire'];
	$plus=$exp + $expire;
	


date_default_timezone_set('Asia/Rangoon');
	$script_tz = date_default_timezone_get();
	if(strcmp($script_tz, ini_get('date.timezone')))
	{
		$ans=date("h:i:sa");
		$request2=date('d-m-y');
	}
	else
	{
		echo 'Script timezone and ini-set timezone match.';
	}
	//echo $exp;
	//echo $call['start_date_time'];
	
	
	
			
			/*(For Insert)*/
		$timestamp = date('Y-m-d H:i:s');
		$start_date = date($timestamp);
		
		$expires = strtotime("$ex_date", strtotime($timestamp));
		//$expires = date($expires);

		$date_diff=($expires-strtotime($timestamp)) / 86400;

			$start=$timestamp;
			$end=date('Y-m-d H:i:s', $expires)."</br>";
			$round=round($date_diff, 0);
			
		
			if(!$userid)
			{
					$st_date1="U have no active Package";
					//$ex_date2="U have no active Package";
					//$exp3="U have no active Package";
			}
			else
			{
				if($userid)
				{
			$insert="UPDATE package_log set Packexpire='$round' WHERE user_id='$user_id'";
			$update=mysqli_query($mysqli,$insert);
			if($update)
			{
				
				if($ex_date<=$start_date)
				{
				$delete="DELETE FROM package_log WHERE user_id='$user_id'";
				$confirm=mysqli_query($mysqli,$delete);
				if($confirm)
				{
					$st_date1="U have no active Package";
					//$ex_date2="U have no active Package";
					//$exp3="U have no active Package";
				}
				
				}
				else
				{
					$st_date1="<font color='blue'>သက်တမ်းတိုးသည့်ရက် - </font></br> $st_date";
					$ex_date2="<font color='red'>သက်တမ်းကုန်ဆုံးရက် - </font></br> $ex_date ";
					$exp3="<font color='red'>သက်တမ်း ကျန်ရှိသည့် ရက်  : </font> </br>$exp ရက်";
					$exp4="$exp";
				}
			}
				
			}
			
			}
		
		

?>
                    <div class="card col-sm-5 col-md-4 col-lg-4 mb mr-auto ml-auto shadow p-3 mb-5 bg-white rounded" style="width: 18rem;">
                        <div class="card-body bd ">
                            <h5 class="card-title ">ပက်ကေ့ချ် လက်ကျန်</h5>
                            <hr>
                           
							<h6 class="card-subtitle mb-2 text-muted -middle"> <br><?php error_reporting(1); echo "$exp3"; ?></h6>
							<?php 
							error_reporting(1);
							if(!$userid)
							{
								$err="error";
							}
							else
							{
							if($exp4)
							{
								
								$ans=$exp4/365*100;
								if($exp4<=7)
								{
									echo "<div class='progress'>
										<div class='progress-bar bg-danger' role='progressbar' style='width: $ans%' aria-valuenow='100' aria-valuemin='0' aria-valuemax='100'></div>
									</div></br>";
								}
								else
								{
									if($exp4>=7 &&  $exp4<=30)
									{
										echo"
										<div class='progress'>
											<div class='progress-bar progress-bar-striped' role='progressbar' style='width: $ans%' aria-valuenow='10' aria-valuemin='0' aria-valuemax='100'>$exp4 Days</div>
										</div></br>";
									}
									else
									{
										if($exp4>=30 && $exp<=500)
										{
											echo "
												<div class='progress'>
										<div class='progress-bar bg-success' role='progressbar' style='width: $ans%' aria-valuenow='100' aria-valuemin='0' aria-valuemax='100'></div>
									</div></br>";
										}
										else
										{
											echo"dead";
										}
									}
								}
							}
							}
							?>
							
							<p align="center"><a href="package.php"><button type="button" class="btn btn-primary m-auto">သက်တမ်းတိုးမည် </button></a><br><br>
							 <button type="button" class="btn btn-primary m-auto" data-toggle="modal" data-target="#exampleModal1">
                                <span>ဝယ်ယူခဲ့သည့်မှတ်တမ်း</span>
                                </button></p>
                        </div>
                    </div>

					<div class="card col-sm-6 col-md-4 col-lg-3 mb mr-auto ml-auto shadow p-3 mb-5 bg-white rounded " style="width: 18rem;">
                        <div class="card-body bd">
                            <h5 class="card-title">မကြာမှီ</h5> <br>
                            <hr>
                            <a href="#" class="card-link">ကြည့်ရှူရန်</a>
                            <a href="#" class="card-link">စစ်ဆေးရန်</a>
                        </div>
                    </div>

                    <div class="card col-sm-6 col-md-4 col-lg-3 mb mr-auto ml-auto shadow p-3 mb-5 bg-white rounded" style="width: 18rem;">
                        <div class="card-body bd">
                            <h5 class="card-title">မကြာမှီ</h5> <br>
                            <hr>
                            <a href="#" class="card-link">ပြန်လည်ကြည့်ရှူရန်</a>
                            <a href="#" class="card-link text-center">ပြင်ဆင်ရန်</a>
                        </div>
                    </div>
					

					

							
						
							
                    <div class="card col-sm-6 col-md-4 col-lg-4 mb mr-auto ml-auto shadow p-3 mb-5 bg-white rounded" style="width: 18rem;">
                        <div class="card-body bd">
                            <h5 class="card-title">မကြာမှီ </h5>

                            <p class="card-text">အစမ်းသုံး</p>
                            <p class="card-text">သာမာန်</p>
                            <p class="card-text">လုံခြုံရေး</p>
                            <p class="card-text">အထူးဝန်ဆောင်မှူ</p>


                        </div>
                    </div>


                   

                    



                </div>


            </div>

		<?php } } ?>
            <!-----end------>


            <!--footer bar-->
            <footer>
                <div class="container-fluid foot text-center">
                    Power By MWTC

                </div>
            </footer>
<!------------- User Edit --------------->

            <?php
                include("engine/connection.php");
               session_start();
                $result = mysqli_query($mysqli, "SELECT * FROM register where userid='{$_SESSION['userid']}'");
                $row = mysqli_fetch_assoc($result);


                ?>
                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">ပရိုဖိုင်ပြင်ဆင်ရန်</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="engine/user_edit.php" method="post">
                                    <div class="form-group">
                                        <label for="my-input">အမည်</label>
                                        <input id="my-input" class="form-control" type="text" name="name" value="<?php echo $row['name'];  ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="my-input">ဖုန်းနံပါတ်</label>
                                        <input id="my-input" class="form-control" type="text" name="phone" value="<?php echo $row['phone']  ?>">
                                    </div>

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">ပြန်ထွက်ရန် </button>
                                <input type="submit" class="btn btn-primary" value="ပြင်ဆင်မည်">
                            </div>
                            </form>

                        </div>
                    </div>
                </div>
                
                <!----------------------------package------------------------------->
           
				<div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModal1Label" aria-hidden="true">
					<div class="modal-dialog" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title" id="exampleModal1Label">သင်ဝယ်ယူခဲ့သည့်မှတ်တမ်းများ</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
							     <?php
				include("engine/connection.php");
				session_start();
				$result = mysqli_query($mysqli, "SELECT * FROM customer_log WHERE user_id='{$_SESSION['userid']}' ORDER BY ID DESC");
				while($row = mysqli_fetch_assoc($result))
				{


				?>
								<form action="engine/user_edit.php" method="post">
									<div class="alert alert-primary alert-dismissible fade show" role="alert">
										ဂုဏ်ယူပါတယ် <?php echo $_SESSION['usname'];  ?> ။ <?php echo $row['package_name'];  ?> <?php echo $row['Packexpire'];  ?>ရက်စာ ပက်ကေ့ချ် ဝယ်ယူချင်းအောင်မြင်ပါတယ်။
										ဝယ်ယူသည့်ရက်မှာ <?php echo $row['start_date_time'];  ?> ကုန်ဆုံးရက်မှာ <?php echo $row['expire_date_time']; ?> ပါသည်။
										<buttom type="button" class="close" data-dismiss="alert" aria-lable="Close"><span aria-hidden="true">&times;</span></buttom>
									</div>
							<?php } ?>	

							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-secondary" data-dismiss="modal">ပြန်ထွက်ရန် </button>

							</div>
							</form>

						</div>
					</div>
				</div>
				
				
				<!-------modu3----->
				<div class="modal fade" id="exampleModal3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">ကုန်စိမ်း ပစ္စည်းများတင်ရန်</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form  method="post">
                                    <div class="form-group">
                                        <label for="my-input">ကုန်ပစ္စည်းပုံ</label>
                                        <input id="my-input" class="form-control" type="file" name="" value="">
                                    </div>
                                    <div class="form-group">
                                        <label for="my-input">ပစ္စည်းအမျိုး အမည်</label>
                                        <input id="my-input" class="form-control" type="text" name="" value="">
                                    </div>
                                    <div class="form-group">
                                        <label for="my-input"> ပိဿချိန်</label>
                                        <select class="form-control"  name=""><option>1</option><option>2</option><option>3</option><option>4</option></select>
                                    </div>
                                    <div class="form-group">
                                        <label for="my-input">ပျမ်းမျှဈေးနှုန်း</label>
                                        <input id="my-input" class="form-control" type="text" name="" value="">
                                    </div>

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">ပြန်ထွက်ရန် </button>
                                <input type="submit" class="btn btn-primary" value="ပြင်ဆင်မည်">
                            </div>
                            </form>

                        </div>
                    </div>
                </div>
                <!-------modu4----->
				<div class="modal fade" id="exampleModal4" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">ကုန်ခြောက် ပစ္စည်းများတင်ရန် </h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form  method="post">
                                    <div class="form-group">
                                        <label for="my-input">ကုန်ပစ္စည်းပုံ</label>
                                        <input id="my-input" class="form-control" type="file" name="" value="">
                                    </div>
                                    <div class="form-group">
                                        <label for="my-input">ပစ္စည်းအမျိုး အမည်</label>
                                        <input id="my-input" class="form-control" type="text" name="" value="">
                                    </div>
                                    <div class="form-group">
                                        <label for="my-input"> အရည်အတွက်</label>
                                        <select class="form-control"  name=""><option>1</option><option>2</option><option>3</option><option>4</option></select>
                                    </div>
                                    <div class="form-group">
                                        <label for="my-input">ပျမ်းမျှဈေးနှုန်း</label>
                                        <input id="my-input" class="form-control" type="text" name="" value="">
                                    </div>

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">ပြန်ထွက်ရန် </button>
                                <input type="submit" class="btn btn-primary" value="ပြင်ဆင်မည်">
                            </div>
                            </form>

                        </div>
                    </div>
                </div>
				
                <!----------------------------- end ----------------------------->
            <!--bootstrap js-->
           <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
            <!--fontawesome js-->
            <script src="./js/all.js"></script>

            <!--jquery-->
            <script src="./js/jquery-3.5.0.min.js"></script>
            <script src="./js/jquery.min.js"></script>
            <!--menu js-->

            <script>
                $("#menu-toggle").click(function(e) {
                    e.preventDefault();
                    $("#wrapper").toggleClass("toggled");
                });
            </script>

</body>

</html>
	<?php } ?>
							
<!--<script>
    $("#menu-toggle").click(function (e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>-->